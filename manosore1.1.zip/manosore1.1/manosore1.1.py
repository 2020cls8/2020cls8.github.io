import random,sys,time,threading,tkinter.messagebox, os
from tkinter import *

sys.setrecursionlimit(10000)

global w,h,ms,statue,swept,mode,l_skill,c,lev,marked,afterRe

options=[]
with open("res/cfg.txt", "r") as file:
    for line in file:
        line = line.strip()
        options.append(line)

mine=[]
now=[]
emp=[]
marked=[]
statue='first'
swept=False
relife=True

mode=options[0]
w=int(options[1])
h=int(options[2])
ms=int(options[3])

lev=options[4]
if lev=='易':
    timeLimit=ms*10
if lev=='中':
    timeLimit=ms*5
if lev=='难':
    timeLimit=ms*2
if lev=='关':
    timeLimit='0'

for i in range(w*h):
    now.append(' ')

def hiro():
    tkinter.messagebox.showerror('二阶堂希罗','不好，做了不正确的抉择！\n下次一定要拯救艾玛和大家...')

def calc(m,n,s):
    global statue,wing,relife,mode,afterRe

    #if w*n+m < 0:
    if n<0 or m<0 or m>w-1 or afterRe:
        return

    num=['0','1','2','3','4','5','6','7','8']
    if w*n+m in mine and s:
        
        if mode=='1' and relife:
            relife=False
            afterRe=True
            t=threading.Thread(target=hiro)
            t.start()
            return
            
        for i in mine:
            now[i]='9'

        #show()
        for b in f.winfo_children():
            b.destroy()

        for b in f1.winfo_children():
            b.destroy()
           
        f.config(bg='black')
        f1.config(bg='black')
        l_lose=Label(f1,text='BAD END',fg='white',bg='black',font=("Georgia",25,'bold'))#结束
        l_lose.place(x=100,y=200)
        if statue!='timeup':
            statue='lose'
        return


    elif w*n+m in mine and not s:
        return

        
    mineAround=0
    exp=[(m-1,n),(m,n-1),(m+1,n),(m,n+1),(m-1,n-1),(m-1,n+1),(m+1,n-1),(m+1,n+1)]
    grip=[w*n+m-1, w*n+m+1, w*n+m-w, w*n+m-w+1, w*n+m-w-1, w*n+m+w, w*n+m+w-1, w*n+m+w+1]
    if m==0:
        grip=[w*n+m+1,w*n+m-w, w*n+m-w+1, w*n+m+w, w*n+m+w+1]
        
    if m==w-1:
        grip=[w*n+m-1,w*n+m-w, w*n+m-w-1, w*n+m+w, w*n+m+w-1]
    for i in grip:      
        if i in mine:
            mineAround=mineAround+1
    try:
        now[w*n+m]=num[mineAround]
    except IndexError:
        return
    k=0
    for i in now:
        if i==' ':
            k=k+1
    if k==ms:
        statue='win'
        for b in f.winfo_children():
            b.destroy()

        for b in f1.winfo_children():
            b.destroy()
        if mode=='0':
            wing = PhotoImage(file="res/win1.gif")


        if mode=='1':
            wing = PhotoImage(file="res/win2.gif")
        l_win=Label(f1, image=wing)
        l_win.place(x=0, y=0)
        l_winfo=Label(f,text='WIN !',fg=color1,font=("Georgia",30,'bold'))
        l_winfo.place(x=20, y=10)
            
        return
        
    if mineAround==0 and w*n+m not in emp :
        emp.append(w*n+m)
        for (p,q) in exp:
            try:
                calc(p,q,False)
            except IndexError:
                return
    else:
        pass

def restart():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def create(m,n):
    grip=[w*n+m, w*n+m-1, w*n+m+1, w*n+m-w, w*n+m-w+1, w*n+m-w-1, w*n+m+w, w*n+m+w-1, w*n+m+w+1]
    i=0
    while i<ms:
        x=random.randint(0,w*h-1)
        if x not in mine and x not in grip:
            mine.append(x)
            i=i+1
    #print(mine)
    calc(m,n,True)


def pi(v,a):
    global statue,swept,mode,sk,l_skill,afterRe

    afterRe=False
    
    if statue=='first':
        if mode=='0':
            sk=PhotoImage(file="res/skill.gif")
            l_skill=Label(f1,image=sk)
            l_skill.place(x=10,y=100)
            l_skill.bind("<Button-1>", hint)
        l_rest.config(text='还剩'+str(ms)+'个')
        if mode=='0':
            l_rest.place(x=70,y=30)
        if mode=='1':
            l_rest.place(x=60,y=40)
        create(int(v)%w,int(v)//w)
        statue='playing'
    elif statue=='win' and not swept:   #判断胜负
        return
    elif statue=='lose' and not swept:
        return
    elif statue=='timeup':
        return
    elif v in marked:
        return
    else:
        calc(int(v)%w,int(v)//w,True)
        swept=False

    colors=[color2, 'blue', 'green', 'red', '#CC6CE7', '#FE9900', '#060270', '#060270', '#060270', 'black']
    
    i=0
    for b in wi.winfo_children():
        if b.winfo_class() == 'Button':
            if now[i]=='9':
                b.config(text='@', bg='red',fg='black')
            elif now[i]!=' ':
                b.config(text=now[i], bg=color2,fg=colors[int(now[i])])
            elif b.cget('text')!='▲':
                b.config(bg=color1)
            i=i+1

def sweep(e):
    global statue,swept
    

    if statue!='playing':
        return
    swept=True
    m=e%w
    n=e//w
    exp=[(m-1,n),(m,n-1),(m+1,n),(m,n+1),(m-1,n-1),(m-1,n+1),(m+1,n-1),(m+1,n+1)]
    if m==0:
        exp=[(m,n-1),(m+1,n-1),(m+1,n+1),(m,n+1),(m+1,n)]
        
    if m==w-1:
        exp=[(m,n-1),(m-1,n-1),(m-1,n+1),(m,n+1),(m-1,n)]

    k=0
    for (p,q) in exp:
        if w*q+p in marked:
            k=k+1

    if k==int(now[e]):
        for (p,q) in exp:
            if w*q+p not in marked:
                calc(p,q,True)
        pi(e,True)

def mark(e):
    global statue,marked
    if statue!='playing':
        return

    #sweep(e)
    n=0
    for b in wi.winfo_children():
        if b.winfo_class() == 'Button' :
            if n==e and b.winfo_class() == 'Button' :

                if b.cget('text')=='▲':
                    marked.remove(e)
                    b.config(text='?', fg='white')
                    
                elif b.cget('text')=='?':
                    b.config(text=' ')
                    
                elif b.cget('text')==' ':
                    marked.append(e)
                    b.config(text='▲', fg='red')
            n=n+1
    if ms-len(marked) <=0:
        s=0
    else:
        s=ms-len(marked)
    l_rest.config(text='还剩'+str(s)+'个')

            
def countdown(k):
    global statue, yk,c
    c=k
    #c=90
    while c:
        if statue=='playing' and timeLimit!='0':
            m, s = divmod(c, 60)
            timer = '{:02d}:{:02d}'.format(m, s)
            l1.config(text=timer)
            time.sleep(1)
            c -= 1
    if statue!='lose' and statue!='win':
        for b in f.winfo_children():
            b.destroy()
        for b in f1.winfo_children():
            b.destroy()
        yk = PhotoImage(file="res/timeup.gif")
        l_yk=Label(f1, image=yk)
        l_yk.place(x=0, y=0)
        wi.update()
        statue='timeup'
        l_time=Label(f,text='TIME UP',fg='red',font=("Georgia",30,'bold'))
        l_time.place(x=60, y=10)
    else:
        countdown(timeLimit)
        

def hint(e):
    global l_skill
    n=0
    tar=[]
    for b in wi.winfo_children():
        if b.winfo_class() == 'Button' :
            if n not in marked and n in mine:
                tar.append(n)
            n=n+1

    #print(tar)
    x=tar[random.randint(0,len(tar)-1)]
    mark(x)
    l_skill.destroy()



def newGame():
    global c,statue
    try:
        l_skill.destroy()
    except:
        pass
    prepare()
    if timeLimit!='0':
        l1.config(text=timer)
    statue='first'
    c=timeLimit
    emp.clear()
    marked.clear()
    now.clear()
    mine.clear()
    for i in range(w*h):
        now.append(' ')  
    for b in wi.winfo_children():
        if b.winfo_class() == 'Button' :
            b.config(text=' ',bg=color1)


            
wi=Tk()
    #b.bind('<Button-3>', mark_)

f=Frame(wi,width=300)
f1=Frame(wi,width=300)
#f.pack_propagate(0)

def book(e):
    global inf,n
    n=True
    def change():
        global inf,n
        if n:
            inf = PhotoImage(file="res/info_hiro.gif")
            n=False
        else:
            inf = PhotoImage(file="res/info_ema.gif")
            n=True
            
        l_dia=Label(bo, image=inf)
        l_dia.place(x=0, y=0)
        b1=Button(bo, text='下一页',bg='#958d8b', command=change)
        b1.place(x=750, y=400)
        
    bo=Toplevel()
    bo.geometry("860x450")
    bo.title('魔女图鉴')
    bo.config(bg='#958d8b')
    inf = PhotoImage(file="res/info_ema.gif")
    l_dia=Label(bo, image=inf)
    l_dia.place(x=0, y=0)
    b1=Button(bo, text='下一页',bg='#958d8b', command=change)
    b1.place(x=750, y=400)
    bo.mainloop()

def settings():
    def apply():
        lines=[]
        if chara.get() =='樱羽艾玛':
            lines.append("0\n")

        else:
            lines.append("1\n")

        w=e1.get()
        h=e2.get()
        ms=e3.get()
        
        if int(w)>=5:
            lines.append(w+"\n")
        else:
            lines.append("10\n")
        if int(h)>=10:
            lines.append(h+"\n")
        else:
             lines.append("10\n")

            
        if int(ms)>=5 and int(ms)<=int(w)*int(h)-10:
            lines.append(ms+'\n')
        else:
            lines.append('10\n')
        lines.append(tim.get())
        
        file = open("res/cfg.txt", "w")
        file.writelines(lines)
        file.close()
        if tkinter.messagebox.askyesno('魔女提示','是否立即重启程序以应用更改？\n你当前的游戏将丢失。'):
            restart()
        sti.destroy()
            
    def fast1():
        e1.delete(0, END)
        e2.delete(0, END)
        e3.delete(0, END)
        e1.insert(0,'9')
        e2.insert(0,'10')
        e3.insert(0,'10')
        
    def fast2():
        e1.delete(0, END)
        e2.delete(0, END)
        e3.delete(0, END)
        e1.insert(0,'16')
        e2.insert(0,'16')
        e3.insert(0,'40')    
            
    def fast3():
        e1.delete(0, END)
        e2.delete(0, END)
        e3.delete(0, END)
        e1.insert(0,'30')
        e2.insert(0,'16')
        e3.insert(0,'99')    
        
    sti=Toplevel()
    sti.title('设置')
    la1=Label(sti,text='行数')
    e1=Entry(sti,width=5)
    la2=Label(sti,text='列数')
    e2=Entry(sti,width=5)
    la3=Label(sti,text='雷数')
    e3=Entry(sti,width=5)
    la4=Label(sti,text='主角')
    b2=Button(sti,text='应用',command=apply)
    
    la8=Label(sti,text='快速设置')
    f1=Button(sti,text='初级(9x10, 10个雷)  ',command=fast1)
    f2=Button(sti,text='中级(16x16, 40个雷)',command=fast2)
    f3=Button(sti,text='高级(30x16, 99个雷)',command=fast3)
    la8.place(x=0, y=10)
    f1.place(x=20,y=30)
    f2.place(x=20,y=70)
    f3.place(x=20,y=110)

    characters=['樱羽艾玛','二阶堂希罗']
    chara = StringVar(sti)
    chara.set(characters[int(mode)])
    e4=OptionMenu(sti, chara, *characters)

    la5=Label(sti,text='时限')
    la6=Label(sti,text='                                                                                                                              ')
    la7=Label(sti,text='manosore V1.1\n入江')

    ti=['易','中','难','关']
    tim = StringVar(sti)
    tim.set(lev)
    e5=OptionMenu(sti, tim, *ti)    

    e1.insert(0,w)
    e2.insert(0,h)
    e3.insert(0,ms)
    
    la1.pack()
    e1.pack()
    la2.pack()
    e2.pack()
    la3.pack()
    e3.pack()
    la4.pack()
    e4.pack()
    la5.pack()
    e5.pack()
    la6.pack()
    b2.pack()
    la7.pack()
    sti.mainloop()            

def prepare():  #初始化
    global cr,dia,note,timer,l_rest,ct,l1,relife,mode,color1,color2,w,h
    mode=options[0]
    w=int(options[1])
    h=int(options[2])
    if mode=='0':
        color1='#fbb3c3'
        color2='#fef2f5'
    if mode=='1':
        color1='#ca6c85'
        color2='#f6e7eb'
        
    relife=True
    if statue=='timeup':
        c=threading.Thread(target=lambda c=timeLimit:countdown(c))
        c.start()   
    f.config(bg='#f0f0f0')
    f1.config(bg='#f0f0f0')
    for b in f.winfo_children():
        b.destroy()
    for b in f1.winfo_children():
        b.destroy()
    if timeLimit!='0':
        ct = PhotoImage(file="res/timer.gif")
        l_timeback = Label(f, image=ct)
        l_timeback.place(x=135,y=10)
        l1=Label(f,text='',fg='white',bg='#1d0e0c',font=("Cambria",16,'bold'))
        l1.place(x=195,y=23)
        m, s = divmod(timeLimit, 60)
        timer = '{:02d}:{:02d}'.format(m, s)
        l1.config(text=timer)


    if mode=='0':
        
        cr = PhotoImage(file="res/ema.gif")
        l_char=Label(f1, image=cr)
        l_char.place(x=117,y=15)
        dia = PhotoImage(file="res/dia.gif")
        l_dia=Label(f1, image=dia)
        l_dia.place(x=14, y=0)

        l_rest=Label(f1,text='一起...活下去！',font=("仿宋",11,'bold'),bg='#e1ccca', fg='#5b4c49')
        l_rest.place(x=40,y=30)

    if mode=='1':
        cr = PhotoImage(file="res/hiro.gif")
        l_char=Label(f1, image=cr)
        l_char.place(x=108,y=0)
        dia = PhotoImage(file="res/dia.gif")
        l_dia=Label(f1, image=dia)
        l_dia.place(x=0, y=10)

        l_rest=Label(f1,text='说正确的事吧？',font=("仿宋",11,'bold'),bg='#e1ccca', fg='#5b4c49')
        l_rest.place(x=30,y=40)
      

            
    note = PhotoImage(file="res/note.gif")
    l_note=Label(f,image=note)
    l_note.place(x=5,y=0)
    l_note.bind('<Button-1>', book)

def shut():
    os._exit(0)

prepare()
for i in range(w*h):

    b=Button(wi,bg=color1,width='2',text=' ',font=("SistersFB",16,'bold'),command=lambda v=i:pi(int(v),False))
    b.grid(row=i//w, column=i%w)
    exec('def mark'+str(i)+'(e):\n    mark('+str(i)+')\nb.bind("<Button-3>", mark'+str(i)+')')
    exec('def sweep'+str(i)+'(e):\n    sweep('+str(i)+')\nb.bind("<Double-Button-1>", sweep'+str(i)+')')

if timeLimit!='0':
        c=threading.Thread(target=lambda c=timeLimit:countdown(c))
        c.start()

wi.title('manosore')
wi.protocol("WM_DELETE_WINDOW", shut)
tools = Menu(wi) 
tools.add_command(label = '新游戏',command=newGame)
tools.add_command(label = '设置',command=settings)
wi.config(menu = tools)

wi.resizable(False, False)
f1.grid(row=h-8, column=w, pady=0,sticky=S+N,rowspan=8,columnspan=10)
f.grid(row=0, column=w, pady=0,sticky=S+N,rowspan=h-8,columnspan=10)

wi.mainloop()

